General Semiconductor Spice model files often use the .TXT extension.

5Spice does not recognize this file extension as a model file.

Change the file extension to  .LIB