Texas Instruments op amp macromodels all use the following node assignments:
1: noninverting input
2: inverting input
3: positive power supply
4: negative power supply
5: output
Some of them also use these two nodes:
6: compensating terminal 1
7: compensating terminal 2
